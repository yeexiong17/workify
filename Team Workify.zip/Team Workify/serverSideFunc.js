function getDataForSearch() {
    const sheetId = '15L9SYMDR6BmOJWojmwAtpoyq4BEdeM2c4hftyADMCsc';
    const ss = SpreadsheetApp.openById(sheetId);
    const ws = ss.getSheetByName("Job");
    //get ws data from row 2, column
    return ws.getRange(2, 1, ws.getLastRow() - 1, 5).getValues();//row,column,numRows,numColumns 3 (initial value) numCol put 5 if want to get 5
}


//const id ='15L9SYMDR6BmOJWojmwAtpoyq4BEdeM2c4hftyADMCsc';
//const sheet = SpreadsheetApp.openById(id).getSheetByName('Job');

function deleteById(id) {
    //const id = "eed14577"; //test: manually delete from backend
    const sheetId = '15L9SYMDR6BmOJWojmwAtpoyq4BEdeM2c4hftyADMCsc';
    const ss = SpreadsheetApp.openById(sheetId);
    const ws = ss.getSheetByName("Job");
    const jobIds = ws.getRange(2, 1, ws.getLastRow() - 1, 1).getValues().map(r => r[0].toString().toLowerCase()); //toString convert smgt to string
    //use .map(r => r[0] to convert [[3],[34],[44]] to [3,34,44] so that we can use indexOf(used in a single dimensional array)
    const posIndex = jobIds.indexOf(id);
    const rowNumber = posIndex === -1 ? 0 : posIndex + 2;
    ws.deleteRow(rowNumber);
}

function getJobById(id) {
    const sheetId = '15L9SYMDR6BmOJWojmwAtpoyq4BEdeM2c4hftyADMCsc';
    const ss = SpreadsheetApp.openById(sheetId);
    const ws = ss.getSheetByName("Job");
    const jobIds = ws.getRange(2, 1, ws.getLastRow() - 1, 1).getValues().map(r => r[0].toString().toLowerCase());
    const posIndex = jobIds.indexOf(id);
    const rowNumber = posIndex === -1 ? 0 : posIndex + 2;
    const jobInfo = ws.getRange(rowNumber, 1, 1, 5).getValues()[0]; //TODO : can change 4 depends on how many params want to edit . put 4 if return 4
    //[[45, "Joe"]]
    return {
        jobID: jobInfo[0],
        firstName: jobInfo[1],
        lastName: jobInfo[2],
        phone: jobInfo[3],
        workMode: jobInfo[4]
    }
}

function editJobById(id, jobInfo) {
    const sheetId = '15L9SYMDR6BmOJWojmwAtpoyq4BEdeM2c4hftyADMCsc';
    const ss = SpreadsheetApp.openById(sheetId);
    const ws = ss.getSheetByName("Job");
    const jobIds = ws.getRange(2, 1, ws.getLastRow() - 1, 1).getValues().map(r => r[0].toString().toLowerCase());
    const posIndex = jobIds.indexOf(id);
    const rowNumber = posIndex === -1 ? 0 : posIndex + 2;
    //col 2 coz no need change id;numCol 3 coz first, last, phone
    ws.getRange(rowNumber, 2, 1, 4).setValues([[  //put 4 if return 4
        jobInfo.firstName,
        jobInfo.lastName,
        jobInfo.phone,
        jobInfo.workMode
    ]]);
    return true;

}


function addJob(jobInfo) {
    const sheetId = '15L9SYMDR6BmOJWojmwAtpoyq4BEdeM2c4hftyADMCsc';
    const ss = SpreadsheetApp.openById(sheetId);
    const ws = ss.getSheetByName("Job");
    const uniqueIDs = ws.getRange(2, 1, ws.getLastRow() - 1, 1).getValues();
    var maxNum = 0;
    uniqueIDs.forEach(r => {
        maxNum = r[0] > maxNum ? r[0] : maxNum
        /*if(r[0] > maxNum){
          maxNum = r[0];
        } */
    });
    var newID = maxNum + 1;
    ws.appendRow([
        newID,
        jobInfo.firstName,
        jobInfo.lastName,
        jobInfo.phone,
        jobInfo.workMode
    ]);
}

function sendEmailOpenById(id) {
    const updatedJobInfo = getJobById(id);
    Logger.log("Updated Job Info: %s", JSON.stringify(updatedJobInfo));

    const htmlBody = `    
      <h2>Opening Job Position for ${updatedJobInfo.firstName}</h2>
      <p>Dear HR Department,</p>
      <p>
  I would like to inform you that we have a new job opening for the position of ${updatedJobInfo.firstName} in the ${updatedJobInfo.firstName} Department. We are now accepting applications for this position, and I kindly ask that you create and activate this listing on all third-party job platforms such as LinkedIn.
  </p>  
      <table class=class="table table-striped table-bordered table-group-divider table-hover" style=" border: 1px solid black;
    border-collapse: collapse; text-align:left;">
        <thead>
          <tr>
            <th scope="col" class="text-end" style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px;">Job ID:</th>
            <td style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px 100px 10px 10px;">${updatedJobInfo.jobID}</td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="col" style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px;">Job Position:</th>
            <td style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px 100px 10px 10px;">${updatedJobInfo.firstName}</td>
          </tr>
          <tr>
            <th scope="col" style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px;">Job Type:</th>
            <td style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px 100px 10px 10px;">${updatedJobInfo.lastName}</td>
          </tr>
          <tr>
            <th scope="col" style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px;">Work Mode:</th>
            <td style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px 100px 10px 10px;">${updatedJobInfo.workMode}</td>
          </tr>
          <tr>
            <th scope="col" style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px;">Salary (RM):</th>
            <td style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px 100px 10px 10px;">${updatedJobInfo.phone}</td>
          </tr>
        </tbody>
      </table>
  
      <p>Please confirm once the job listings have been posted and are live. Your timely action on this matter will help us attract the best candidates and maintain the efficiency of our hiring process.</p>  
  
      <p>Thank you very much for your cooperation and support</p>
  
      <p>Best regards,<br>HR Team</p>
    `;

    GmailApp.sendEmail("eemunsm@gmail.com", "Job Position Status Updated", "", {
        htmlBody: htmlBody,
        name: "HR Department"
    });

    return true;
}


function sendEmailCloseById(id) {
    const updatedJobInfo = getJobById(id);
    Logger.log("Updated Job Info: %s", JSON.stringify(updatedJobInfo));

    const htmlBody = `    
      <h2>Closing Job Position for ${updatedJobInfo.firstName}</h2>
      <p>Dear HR Department,</p>
      <p>
  I would like to inform you that the job opening for the position of ${updatedJobInfo.firstName} in the ${updatedJobInfo.firstName} department has now been officially closed. We are no longer accepting applications for this position, and I kindly ask that you remove or deactivate this listing from all third-party job platforms such as LinkedIn.
  </p>  
      <table class=class="table table-striped table-bordered table-group-divider table-hover" style=" border: 1px solid black;
    border-collapse: collapse; text-align:left;">
        <thead>
          <tr>
            <th scope="col" class="text-end" style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px;">Job ID:</th>
            <td style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px 100px 10px 10px;">${updatedJobInfo.jobID}</td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="col" style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px;">Job Position:</th>
            <td style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px 100px 10px 10px;">${updatedJobInfo.firstName}</td>
          </tr>
          <tr>
            <th scope="col" style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px;">Job Type:</th>
            <td style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px 100px 10px 10px;">${updatedJobInfo.lastName}</td>
          </tr>
          <tr>
            <th scope="col" style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px;">Work Mode:</th>
            <td style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px 100px 10px 10px;">${updatedJobInfo.workMode}</td>
          </tr>
          <tr>
            <th scope="col" style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px;">Salary (RM):</th>
            <td style=" border: 1px solid black;
    border-collapse: collapse; text-align:left; padding: 10px 100px 10px 10px;">${updatedJobInfo.phone}</td>
          </tr>
        </tbody>
      </table>
  
      <p>Please confirm once the job listings have been updated to 'closed' status. Your timely action on this matter will help us manage candidate expectations and maintain our hiring process's efficiency.</p>  
  
      <p>Thank you very much for your cooperation and support</p>
  
      <p>Best regards,<br>HR Team</p>
    `;

    GmailApp.sendEmail("eemunsm@gmail.com", "Job Position Status Updated", "", {
        htmlBody: htmlBody,
        name: "HR Department"
    });

    return true;
}



function getDataForSearchApplications() {
    const sheetId = '15L9SYMDR6BmOJWojmwAtpoyq4BEdeM2c4hftyADMCsc';
    const ss = SpreadsheetApp.openById(sheetId);
    const ws = ss.getSheetByName("Applications");
    //get ws data from row 2, column
    return ws.getRange(2, 1, ws.getLastRow() - 1, 11).getValues();//row,column,numRows,numColumns 3 (initial value) numCol put 5 if want to get 5
}

function getJobByIdApplications(id) {
    const sheetId = '15L9SYMDR6BmOJWojmwAtpoyq4BEdeM2c4hftyADMCsc';
    const ss = SpreadsheetApp.openById(sheetId);
    const ws = ss.getSheetByName("Applications");
    const appIds = ws.getRange(2, 1, ws.getLastRow() - 1, 1).getValues().map(r => r[0].toString().toLowerCase());
    const posIndex = appIds.indexOf(id);
    const rowNumber = posIndex === -1 ? 0 : posIndex + 2;
    const appInfo = ws.getRange(rowNumber, 1, 1, 8).getValues()[0]; //TODO : can change 4 depends on how many params want to edit . put 4 if return 4
    //[[45, "Joe"]]
    return {
        appID: appInfo[0],
        candidateName: appInfo[1],
        jobName: appInfo[2],
        candidateEmail: appInfo[3],
        candidateResume: appInfo[4],
        status: appInfo[5],
        interviewer: appInfo[6],
        sideNotes: appInfo[7]
    }
}


function editJobByIdApplications(id, appInfo) {
    const sheetId = '15L9SYMDR6BmOJWojmwAtpoyq4BEdeM2c4hftyADMCsc';
    const ss = SpreadsheetApp.openById(sheetId);
    const ws = ss.getSheetByName("Applications");
    const appIds = ws.getRange(2, 1, ws.getLastRow() - 1, 1).getValues().map(r => r[0].toString().toLowerCase());
    const posIndex = appIds.indexOf(id);
    const rowNumber = posIndex === -1 ? 0 : posIndex + 2;
    //col 2 coz no need change id;numCol 3 coz first, last, phone
    ws.getRange(rowNumber, 6, 1, 3).setValues([[  //put 4 if return 4
        appInfo.status,
        appInfo.interviewer,
        appInfo.sideNotes

    ]]);
    return true;

}

function deleteByIdApplications(id) {
    //const id = "eed14577"; //test: manually delete from backend
    const sheetId = '15L9SYMDR6BmOJWojmwAtpoyq4BEdeM2c4hftyADMCsc';
    const ss = SpreadsheetApp.openById(sheetId);
    const ws = ss.getSheetByName("Applications");
    const appIds = ws.getRange(2, 1, ws.getLastRow() - 1, 1).getValues().map(r => r[0].toString().toLowerCase()); //toString convert smgt to string
    //use .map(r => r[0] to convert [[3],[34],[44]] to [3,34,44] so that we can use indexOf(used in a single dimensional array)
    const posIndex = appIds.indexOf(id);
    const rowNumber = posIndex === -1 ? 0 : posIndex + 2;
    ws.deleteRow(rowNumber);
}

function addCandidate(appInfo) {
    const sheetId = '15L9SYMDR6BmOJWojmwAtpoyq4BEdeM2c4hftyADMCsc';
    const ss = SpreadsheetApp.openById(sheetId);
    const ws = ss.getSheetByName("Candidates");
    const uniqueIDs = ws.getRange(2, 1, ws.getLastRow() - 1, 1).getValues();
    var maxNum = 0;
    uniqueIDs.forEach(r => {
        maxNum = r[0] > maxNum ? r[0] : maxNum
        /*if(r[0] > maxNum){
          maxNum = r[0];
        } */
    });
    var newID = maxNum + 1;
    ws.appendRow([
        newID,
        appInfo.firstName,
        appInfo.lastName,
        appInfo.phone,
        appInfo.workMode,
        appInfo.dateTime
    ]);
}

function addCandidateToApplication(appInfo) {
    const sheetId = '15L9SYMDR6BmOJWojmwAtpoyq4BEdeM2c4hftyADMCsc';
    const ss = SpreadsheetApp.openById(sheetId);
    const ws = ss.getSheetByName("Applications");
    const uniqueIDs = ws.getRange(2, 1, ws.getLastRow() - 1, 1).getValues();
    var maxNum = 0;
    uniqueIDs.forEach(r => {
        maxNum = r[0] > maxNum ? r[0] : maxNum
        /*if(r[0] > maxNum){
          maxNum = r[0];
        } */
    });
    var newID = maxNum + 1;
    ws.appendRow([
        newID,
        appInfo.lastName,
        appInfo.firstName,
        appInfo.workMode,
        appInfo.phone
    ]);
}




