function doGet(e) {
    let page = e.parameter.page

    if (page == null) page = "Login"

    var template = HtmlService.createTemplateFromFile(page);
    template.message = '';

    return template.evaluate();
}

function getUrl() {
    return ScriptApp.getService().getUrl();
}

function doPost(e) {
    const id = '15L9SYMDR6BmOJWojmwAtpoyq4BEdeM2c4hftyADMCsc';
    const ss = SpreadsheetApp.openById(id).getSheetByName('Login');
    var userData = ss.getDataRange().getValues();
    for (var i = 0; i < userData.length; i++) {
        if (userData[i][0] == e.parameter.email && userData[i][1] == e.parameter.password) {
            var output = HtmlService.createTemplateFromFile('home');
            // output.username = userData[i][0];
            return output.evaluate().setTitle('home');
        } else if (e.parameter.LogoutButton == 'Logout') {
            var template = HtmlService.createTemplateFromFile('Login');
            template.message = 'Logout';
            return template.evaluate();
        }
    }

    // If password no match so not login
    var template = HtmlService.createTemplateFromFile('login');
    template.message = 'Username or password wrong';
    return template;
}

function handlePage(page) {
    let template;
    switch (page) {
        case 'Login':
            template = HtmlService.createTemplateFromFile('Login');
            break;
        case 'home':
            template = HtmlService.createTemplateFromFile('home');
            break;
        case 'userProfile':
            template = HtmlService.createTemplateFromFile('userProfile');
            break;
        case 'candidate':
            template = HtmlService.createTemplateFromFile('candidate');
            break;
        case 'search':
            template = HtmlService.createTemplateFromFile('search');
            break;
        case 'addJob':
            template = HtmlService.createTemplateFromFile('addjob');
            break;
        case 'leaveMain':
            template = HtmlService.createTemplateFromFile('leaveMain');
            break;
        case 'viewLeave':
            template = HtmlService.createTemplateFromFile('viewLeave');
            break;
        case 'adminProfile':
            template = HtmlService.createTemplateFromFile('adminProfile');
            break;
        case 'leaveRequestList':
            template = HtmlService.createTemplateFromFile('leaveRequestList');
            break;
        case 'dashboard':
            template = HtmlService.createTemplateFromFile('dashboard');
            break;
        case 'applicationStatus':
            template = HtmlService.createTemplateFromFile('applicationStatus');
            break;
        default:
            template = HtmlService.createTemplateFromFile('Login');
    }

    template.message = '';
    return template.evaluate().setTitle(page);
}