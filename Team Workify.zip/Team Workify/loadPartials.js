function loadPartialHTML_(partial) {
    const htmlServ = HtmlService.createTemplateFromFile(partial);
    return htmlServ.evaluate().getContent();
}

function loadSearchView() {
    return loadPartialHTML_("search");
}

function loadAddJobsView() {
    return loadPartialHTML_("addjob");
}

function loadEditJobsView() {
    return loadPartialHTML_("editJob");
}

function loadApplicationView() {
    return loadPartialHTML_("applicationSearch");
}

function loadEditApplicationView() {
    return loadPartialHTML_("editApplication");
}

function loadAddCandidateView() {
    return loadPartialHTML_("addCandidate");
}