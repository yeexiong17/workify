const notionEmployeeDatabaseID = "c3ffe9dade5343629254889a500311e9"
const notionToken = "secret_roLoNAKRs5evindrfyuMe0NDGU9GGRYZOFp5iXIXInS"

function storeNewEmployeeNotion(name, email, department, phone, hireDate) {
    const url = `https://api.notion.com/v1/pages`;

    const payload = {
        parent: { database_id: notionEmployeeDatabaseID },

        properties: {
            'Name': {
                title: [
                    {
                        text: {
                            content: name
                        }
                    }
                ]
            },
            'Email': {
                email: email
            },
            'Department': {
                select: {
                    name: department
                }
            },
            'Phone': {
                phone_number: phone
            },
            'Hire Date': {
                date: {
                    start: hireDate
                }
            },
        }
    };

    const options = {
        method: 'POST',
        contentType: 'application/json',
        headers: {
            'Authorization': `Bearer ${notionToken}`,
            'Notion-Version': '2022-02-22'
        },
        payload: JSON.stringify(payload)
    };

    const response = UrlFetchApp.fetch(url, options);
    const responseData = JSON.parse(response.getContentText());

    Logger.log(responseData);
}