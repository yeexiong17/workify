function getDashboardData() {

    const dashboardData = {
        allLeaveRequest: getAllLeaveRequest(),
        allEmployee: getAllEmployee(),
        currentYear: new Date().getFullYear(),
        monthlyJobApplicant: getNumOfApplicantEachMonth()
    }

    console.log(dashboardData)

    return dashboardData
}

function getAllEmployee() {
    let lastRow = databaseEmployee.getLastRow()
    let range = databaseEmployee.getRange(1, 1, lastRow, 11)
    let data = range.getValues().slice(1)

    let formattedData = data.map(row => {
        const newDate = formatDate(new Date([2]).toISOString().split('T')[0])

        return [row[0], row[1], row[2], row[3], row[4], row[5], newDate, row[7], row[8], row[9], row[10]]
    })

    return formattedData
}

function getNumOfApplicantEachMonth() {
    let data = googleHackathonDatabase.getSheetByName("Candidates").getDataRange().getValues()

    let applicantCount = {}

    for (var i = 1; i < data.length; i++) {
        let createdAt = data[i][5]

        if (createdAt.getFullYear() == new Date().getFullYear()) {
            let monthYear = createdAt.getFullYear() + '-' + (createdAt.getMonth() + 1)

            if (applicantCount[monthYear]) {
                applicantCount[monthYear]++
            } else {
                applicantCount[monthYear] = 1
            }
        }

    }

    return applicantCount
}

function updateAutoApproval(isChecked, leaveTypeID) {
    const [leaveTypeData, row] = getRowData(leaveTypeID, databaseLeaveType)

    let targetLeaveTypeColumn = databaseLeaveType.getRange(row, 3)
    targetLeaveTypeColumn.setValue(isChecked)

    return true
}