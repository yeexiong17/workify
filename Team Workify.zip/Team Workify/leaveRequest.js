const googleHackathonDatabase = SpreadsheetApp.openById("15L9SYMDR6BmOJWojmwAtpoyq4BEdeM2c4hftyADMCsc")

const databaseLeaveRequest = googleHackathonDatabase.getSheetByName("Leave Request")
const databaseLeaveType = googleHackathonDatabase.getSheetByName("Type of Leave")
const databaseLeavePolicy = googleHackathonDatabase.getSheetByName("Leave Policy")
const databaseEmployee = googleHackathonDatabase.getSheetByName("Employee")

function createRequest(employeeID, startDate, endDate, leaveType, leaveReason) {
    let lock = LockService.getScriptLock()
    lock.waitLock(25000)

    let newStartDate = formatDate(startDate)
    let newEndDate = formatDate(endDate)

    try {
        let totalDaysRequested = calculateLeaveDays(newStartDate, newEndDate) // Measure total days of leave requested
        let requestData = [databaseLeaveRequest.getLastRow(), employeeID, newStartDate, newEndDate, 1, leaveType, totalDaysRequested, leaveReason, null, getDateTimeNow()]

        databaseLeaveRequest.appendRow(requestData)

        let leavePolicyCheck = checkLeavePolicy(totalDaysRequested, leaveType) // Check with leave policy

        let latestRequestData = databaseLeaveRequest.getRange(databaseLeaveRequest.getLastRow(), 1, 1, databaseLeaveRequest.getLastColumn()).getValues()[0]

        if (!leavePolicyCheck) {
            rejectLeaveRequest(latestRequestData[0], "Leave request does not comply with the policy")
        }

        let autoApproveLeave = checkAutoApproveLeave(leaveType) // Check if leave type can be approved automatically

        if (autoApproveLeave) {
            approveLeaveRequest(latestRequestData[0])
        }

    } finally {
        lock.releaseLock()
    }
}

function approveLeaveRequest(requestID) {
    Logger.log("Approving leave request")

    const [targetRequestData, targetRequestRow] = getRowData(requestID, databaseLeaveRequest)
    const [targetEmployeeData, targetEmployeeRow] = getRowData(targetRequestData[1], databaseEmployee)

    // Check if request status is pending
    if (targetRequestData[4] == 1) {
        let targetStatusColumn = databaseLeaveRequest.getRange(targetRequestRow, 5)
        targetStatusColumn.setValue(2)

        let targetModifiedColumn = databaseLeaveRequest.getRange(targetRequestRow, 11)
        targetModifiedColumn.setValue(getDateTimeNow())

        // Deduct from leave balance
        let [leaveType, leaveTypeRow] = getRowData(targetRequestData[5], databaseLeaveType)

        let failReason = deductLeaveBalance(targetRequestData, targetEmployeeData, targetEmployeeRow, leaveType)

        if (failReason) {
            rejectLeaveRequest(requestID, failReason)

            return
        }

        sendEmail(requestID)
    }
}

function rejectLeaveRequest(requestID, rejectReason) {
    Logger.log("Rejecting leave request")

    const [targetRequestData, targetRequestRow] = getRowData(requestID, databaseLeaveRequest)

    // Check if request status is pending
    if (targetRequestData[4] != 3) {
        let targetStatusColumn = databaseLeaveRequest.getRange(targetRequestRow, 5)
        targetStatusColumn.setValue(3)

        let targetReasonColumn = databaseLeaveRequest.getRange(targetRequestRow, 9)
        targetReasonColumn.setValue(rejectReason)

        let targetModifiedColumn = databaseLeaveRequest.getRange(targetRequestRow, 11)
        targetModifiedColumn.setValue(getDateTimeNow())

        sendEmail(requestID)
    }
}

function sendEmail(requestID) {
    Logger.log("Sending Email")

    const [requestData, requestRow] = getRowData(requestID, databaseLeaveRequest)
    const [leaveTypeData, leaveTypeRow] = getRowData(requestData[5], databaseLeaveType)
    const [employeeData, employeeRow] = getRowData(requestData[1], databaseEmployee)

    const htmlBody = `
    <p>Dear ${employeeData[1]} ${employeeData[2]},</p>
    <p>Your leave request has been updated. Here are the details:</p>
    <ul>
      <li><strong>Leave Request ID:</strong> ${requestData[0]}</li>
      <li><strong>Leave Type:</strong> ${leaveTypeData[1]}</li>
      <li><strong>Start Date:</strong> ${requestData[2]}</li>
      <li><strong>End Date:</strong> ${requestData[3]}</li>
      <li><strong>Leave Reason:</strong> ${requestData[7]}</li>
      <li><strong>Status:</strong> ${requestData[4] == 2 ? 'Approved' : 'Rejected'}</li>
      ${leaveTypeData[1].toLowerCase() == "annual leave" ? `<li><strong>Annual Leave Balance:</strong> ${employeeData[9]}</li>` : ''}
      ${requestData[8].length > 0 ? `<li><strong>Reason of Reject:</strong> ${requestData[8]}</li>` : ''}
    </ul>
    <p>Best regards,<br>HR Team</p>
  `

    GmailApp.sendEmail("wongyeexiong10@gmail.com", "Leave Request Status Updated", "", {
        htmlBody: htmlBody,
        name: "HR Department"
    })
}

function deductLeaveBalance(targetRequestData, targetEmployeeData, targetEmployeeRow, targetLeaveType) {
    if (targetLeaveType[1].toLowerCase() != "annual leave") return

    let targetLeaveBalanceColumn = databaseEmployee.getRange(targetEmployeeRow, 10)

    if (targetLeaveBalanceColumn.getValue() - targetRequestData[6] < 0) return 'Leave balance not enough'

    Logger.log("Deducting leave balance")
    targetLeaveBalanceColumn.setValue(targetEmployeeData[9] - targetRequestData[6])
}

function checkAutoApproveLeave(leaveTypeID) {
    Logger.log("Checking for auto approval")

    let allLeaveType = databaseLeaveType.getDataRange().getValues().slice(1)
    let targetLeaveType = allLeaveType.filter(leaveType => leaveType[0] == leaveTypeID)[0]

    if (targetLeaveType[2] == 0) return false

    return true
}

function checkLeavePolicy(numOfDays, leaveType) {
    Logger.log("Checking for leave policy")

    let allLeavePolicy = databaseLeavePolicy.getDataRange().getValues().slice(1)
    let targetLeavePolicy = allLeavePolicy.filter(leavePolicy => leavePolicy[1] == leaveType)[0]

    if (!targetLeavePolicy) return true
    if (numOfDays > targetLeavePolicy[2]) return false

    return true
}

function calculateLeaveDays(startDate, endDate) {
    let startParts = startDate.split('/')
    let endParts = endDate.split('/')

    let start = new Date(parseInt(startParts[2], 10), parseInt(startParts[1], 10) - 1, parseInt(startParts[0], 10))
    let end = new Date(parseInt(endParts[2], 10), parseInt(endParts[1], 10) - 1, parseInt(endParts[0], 10))

    let timeDiff = end - start
    let daysDiff = timeDiff / (1000 * 3600 * 24) + 1

    return daysDiff
}

function getAllLeaveType() {
    return databaseLeaveType.getDataRange().getValues().slice(1)
}

function getAllLeaveRequest() {
    const allLeaveRequest = databaseLeaveRequest.getDataRange().getValues().slice(1)

    const truncatedData = allLeaveRequest.map(row => {
        const startDate = formatDate(new Date(row[2]).toISOString().split('T')[0])
        const endDate = formatDate(new Date(row[3]).toISOString().split('T')[0])
        return [row[0], row[1], startDate, endDate, row[4], row[5], row[6], row[7]]
    })

    const filteredData = truncatedData.filter((leaveRequest) => {
        return leaveRequest[4] == 1
    })

    return filteredData
}

// Helper Function
function getRowData(rowID, database) {
    let requestData = database.getDataRange().getValues().slice(1)
    let targetRow = requestData.findIndex(row => row[0] == rowID) + 2
    let targetData = database.getRange(targetRow, 1, 1, database.getLastColumn()).getValues()[0]

    return [targetData, targetRow]
}

function formatDate(date) {
    let [year, month, day] = date.split('-');
    let newDate = `${day}/${month}/${year}`

    return newDate
}

function getDateTimeNow() {

    let now = new Date()

    return Utilities.formatDate(now, Session.getScriptTimeZone(), 'dd/MM/yyyy HH:mm:ss')
}